package LJlab7;

public class NodeCLL<T> {
	
	T elem;
	NodeCLL<T> next;
	
	@Override
	public String toString() {
		return "NodeCLL [elem=" + String.valueOf(elem) + "]";
	}
	
}
