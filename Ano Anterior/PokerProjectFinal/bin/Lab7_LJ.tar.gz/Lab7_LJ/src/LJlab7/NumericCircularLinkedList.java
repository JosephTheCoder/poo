package LJlab7;

public class NumericCircularLinkedList<T extends Number> extends CircularLinkedList<T>{
		
	public double average(){
		double sum = 0;
		int nb = 0;
		NodeCLL<T> aux = base;
		if (base != null){
			while(aux.next != base){
				sum = sum + aux.elem.doubleValue();
				nb++;
				aux = aux.next;
			}
			sum = sum + aux.elem.doubleValue();
			nb++;
			return sum/nb;
		}else{
			return 0.0;
		}
	
	}
	

}
