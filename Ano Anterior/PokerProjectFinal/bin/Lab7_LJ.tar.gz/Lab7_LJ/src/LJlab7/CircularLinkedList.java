package LJlab7;

public class CircularLinkedList<T> {
	
	NodeCLL<T> base;
	
	public void add(T t){
		if (base == null){
			base = new NodeCLL<T>();
			base.elem = t;
			base.next = base;
		} else {
			NodeCLL<T> aux = new NodeCLL<T>();
			aux.elem = t;
			aux.next = base.next;
			base.next = aux;
		}
	}
	
	public void remove(T t){
		if (base != null){
			NodeCLL<T> aux = new NodeCLL<T>();
			aux = base;
			if(base.elem == t){
				if (base.next == base){
					base = null;
				}else{
					while(aux.next != base){
						aux = aux.next;
					}
					base = base.next;
					aux.next = base;
				}
			}else{
				while(aux.next != base){
					if(aux.next.elem == t){
						aux.next = aux.next.next;
					}
					aux = aux.next;
				}
			}
		}
		
		
	}

	@Override
	public String toString() {
		String str = "CircularLinkedList [";
		NodeCLL<T> aux = new NodeCLL<T>();
		aux = base;
		if (base != null){
			while(aux.next != base){
				str = str + aux + ", ";
				aux = aux.next;
			}
			str = str + aux;
		}
		return str + "]";
	}
	
}
