package Main;

import LJlab7.CircularLinkedList;
import LJlab7.NumericCircularLinkedList;

public class Main {

	public static void main(String[] args) {
		
		CircularLinkedList<Integer> cclist = new CircularLinkedList<Integer>();
		System.out.println(cclist);
		cclist.add(1);
		System.out.println(cclist);
		cclist.add(3);
		System.out.println(cclist);
		cclist.add(2);
		System.out.println(cclist);
		cclist.remove(3);
		System.out.println(cclist);
		cclist.add(4);
		System.out.println(cclist);
		
		NumericCircularLinkedList<Integer> ncclist = new NumericCircularLinkedList<Integer>();
		
		ncclist.add(1);
		ncclist.add(3);
		ncclist.add(2);
		
		System.out.println("Average = " + ncclist.average());
		
	}

}
